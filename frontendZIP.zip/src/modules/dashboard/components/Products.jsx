
import { Product } from "./Product";

export const Products = () => {
  return (
    <div>
      <div className="row">
        <Product />
        <Product />
        <Product />
      </div>
    </div>
  );
};
